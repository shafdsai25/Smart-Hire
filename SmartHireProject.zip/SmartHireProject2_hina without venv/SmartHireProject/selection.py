def shortlist_candidates(alignments, threshold=0.5):  # Lowered the threshold to 0.5
    shortlisted = [alignment for alignment in alignments if alignment['similarity'] >= threshold]
    
    print(f"Threshold: {threshold}")
    for alignment in alignments:
        print(f"Resume: {alignment['resume']['content']}")
        print(f"Job Description: {alignment['job']['content']}")
        print(f"Similarity: {alignment['similarity']}")
        print(f"Shortlisted: {alignment['similarity'] >= threshold}")
        print('-' * 80)
    
    return shortlisted
