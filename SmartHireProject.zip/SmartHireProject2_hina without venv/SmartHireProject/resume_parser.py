
from transformers import pipeline

def parse_resume(resume_path):
    with open(resume_path, 'r') as file:
        resume_content = file.read()

    # Use a language model to extract information
    nlp = pipeline('ner', model='dslim/bert-base-NER')
    entities = nlp(resume_content)

    parsed_resume = {
        'content': resume_content,
        'entities': entities
    }

    return parsed_resume
