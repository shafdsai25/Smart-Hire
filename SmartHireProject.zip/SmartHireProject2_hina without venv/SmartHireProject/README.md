
# Smart Hire - Automated Resume Review System

## Objective
Develop a system that uses Large Language Models (LLMs) to automate the process of reviewing resumes and comparing them with job descriptions to shortlist candidates based on the alignment of their qualifications and the job requirements.

## Project Description
The Smart Hire project leverages the power of LLMs to create a tool that streamlines the hiring process by automating the analysis of resumes and job descriptions. This system will help recruiters efficiently identify the best candidates for a job by evaluating their qualifications and experience against the job requirements using advanced natural language understanding.

## Components
1. **Resume Review**:
    - **Task**: Analyze each candidate's resume.
    - **Details**: Extract and evaluate key information such as qualifications, skills, and experience using LLM capabilities.
2. **Job Description Analysis**:
    - **Task**: Thoroughly review the job description.
    - **Details****: Identify and highlight key requirements and responsibilities of the role using LLM.
3. **Alignment**:
    - **Task**: Compare resume information with the job description.
    - **Details**: Determine the degree of alignment between the candidate's qualifications and the job requirements using semantic matching techniques.
4. **Selection**:
    - **Task**: Shortlist candidates based on alignment.
    - **Details**: Select candidates whose qualifications closely match the job requirements for further evaluation.

## Technologies and Tools
- **Programming Languages**: Python
- **Libraries and Frameworks**:
    - LLMs: OpenAI GPT, Hugging Face Transformers
    - Semantic Matching: Sentence Transformers, BERT
    - Web Interface (optional): Flask or Django

## How to Run
1. Install the required libraries:
    ```bash
    pip install -r requirements.txt
    ```
2. Run the main script:
    ```bash
    python main.py
    ```

## Similar Project Tutorials
1. Enhancing Resume Shortlisting and QA using LangChain, LLM, Retrieval-Augmented Generation (RAG) and Vector stores
2. Leveraging Chatbots for Resume Analysis and Comparison
