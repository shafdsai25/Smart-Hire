
from transformers import pipeline

def parse_job_description(job_path):
    with open(job_path, 'r') as file:
        job_content = file.read()

    # Use a language model to extract key points
    nlp = pipeline('summarization', model='facebook/bart-large-cnn')
    summary = nlp(job_content, max_length=100, min_length=30, do_sample=False)

    parsed_job = {
        'content': job_content,
        'summary': summary
    }

    return parsed_job
