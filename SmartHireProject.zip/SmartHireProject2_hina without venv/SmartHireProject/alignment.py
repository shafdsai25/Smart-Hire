
from sentence_transformers import SentenceTransformer, util

def compare_resume_job(parsed_resume, parsed_job):
    model = SentenceTransformer('bert-base-nli-mean-tokens')

    resume_embedding = model.encode(parsed_resume['content'], convert_to_tensor=True)
    job_embedding = model.encode(parsed_job['summary'][0]['summary_text'], convert_to_tensor=True)

    similarity = util.pytorch_cos_sim(resume_embedding, job_embedding).item()

    alignment = {
        'resume': parsed_resume,
        'job': parsed_job,
        'similarity': similarity
    }

    return alignment
