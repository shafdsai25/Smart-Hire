from resume_parser import parse_resume
from job_description_parser import parse_job_description
from alignment import compare_resume_job
from selection import shortlist_candidates

def main():
    # Load resumes and job descriptions
    resumes = ["resumes/resume1.txt", "resumes/resume2.txt"]
    job_descriptions = ["job_descriptions/job1.txt"]

    print("Parsing resumes...")
    parsed_resumes = [parse_resume(resume) for resume in resumes]
    print(f"Parsed Resumes: {parsed_resumes}")

    print("Parsing job descriptions...")
    parsed_job_descriptions = [parse_job_description(job) for job in job_descriptions]
    print(f"Parsed Job Descriptions: {parsed_job_descriptions}")

    # Compare resumes with job descriptions
    print("Comparing resumes with job descriptions...")
    alignments = [compare_resume_job(resume, job) for resume in parsed_resumes for job in parsed_job_descriptions]
    print(f"Alignments: {alignments}")

    # Shortlist candidates
    print("Shortlisting candidates...")
    shortlisted = shortlist_candidates(alignments)
    
    # Display shortlisted candidates
    print("Shortlisted Candidates:")
    for candidate in shortlisted:
        print(candidate)

if __name__ == "__main__":
    main()
